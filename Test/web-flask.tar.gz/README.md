Web Server avec Python/flask
======================

Exemple de Web server en Python/Flask qui contient une page de saisie de 2 valeurs à diviser pour effectuer des tests.
D’abord ce site devra passer par des tests manuels sur Jmeter et ensuite sur des tests entiérement automatisés.

